# Facebook Ad Interests — Custom GPT Action

ใช้ไฟล์ชุดนี้เพื่อต่อ Custom GPT เข้ากับ Facebook Graph API (adinterest search) และให้ GPT แสดงผลเป็น **ตาราง** อัตโนมัติ

## โครงสร้างไฟล์
- `facebook-adinterests.json` — ไฟล์ Action manifest สำหรับอัปโหลดใน **Custom GPT → Actions**
- `facebook-adinterest-openapi.yaml` — OpenAPI spec ชี้ไปยัง `https://graph.facebook.com/v21.0`

## วิธีใช้ (สรุป)
1) เปิด ChatGPT → Create a GPT → แท็บ **Actions**  
2) คลิก **Upload JSON** แล้วอัปโหลดไฟล์ `facebook-adinterests.json`  
3) แก้ไขค่า `api.url` ใน JSON ให้ชี้ไปยังที่คุณโฮสต์ไฟล์ `.yaml` (เช่น GitHub Raw URL)  
4) ตั้งค่า Auth: วาง **Facebook Marketing API Access Token** (long-lived) ลงในช่องคีย์ของ Action  
5) ใช้งานในแชต เช่น:  
   - `ค้นหา ad interests คำว่า [food] limit 2000 locale en_US`

## หมายเหตุ
- ถ้าต้องการความปลอดภัยสูงขึ้น ให้ทำ Proxy ของคุณเองเพื่อซ่อน Token ฝั่งเซิร์ฟเวอร์
